# coding: utf-8
class SessionsController < ApplicationController
  def create
    member = Member.authenticate(params[:email], params[:password])
    if member
      session[:member_id] = member.id
      if member.admin
        redirect_to :admin_root
      else
        redirect_to :root
      end
    else
      flash.alert = "メールアドレスとパスワードが一致しません"
      redirect_to :login
    end
    #redirect_to params[:from] || :root
  end

  def destroy
    session.delete(:member_id)
    redirect_to :root
  end
end
