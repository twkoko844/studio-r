# coding: utf-8
class TopController < ApplicationController
  def index
  end
  def about
    @text = "スタジオを予約する"
  end
  def login
  end
  def new
  end
end
