class Admin::TopController < Admin::Base
  def index
  end
end
