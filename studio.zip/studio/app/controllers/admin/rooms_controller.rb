# coding: utf-8
class Admin::RoomsController < Admin::Base
  def index
    @rooms = Room.order("id")
  end
end
