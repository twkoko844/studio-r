class Room < ActiveRecord::Base
  # attr_accessible :title, :body
  has_one :booking 
end
