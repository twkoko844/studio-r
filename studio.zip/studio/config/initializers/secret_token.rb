# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Studio::Application.config.secret_token = 'f3a1ad9a4033959bbd94c7af7fa6f0f4fc4d13d2fb5472a16f71c07bb4bb8445e4e20ab77f1cc004cc5f1dcf525bc01036afdfd5e928e497a479d9da65387664'
