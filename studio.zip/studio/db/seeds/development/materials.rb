# coding: utf-8
require "csv"

CSV.foreach('/home/koki/rails/studio/db/seeds/development/Materials_20150118.csv') do |row|
  Material.create(:name => row[1], :kind => MaterialKind.find(row[0]))
end
