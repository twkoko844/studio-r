
1.upto(4) do |idx|
  @room = "room"+idx.to_s
  Room.create(
    name: @room
  )
end
