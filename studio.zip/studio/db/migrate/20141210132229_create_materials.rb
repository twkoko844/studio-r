class CreateMaterials < ActiveRecord::Migration
  def change
    create_table :materials do |t|
      t.string :name
      t.references :material_kind
      t.timestamp :deleted_at
      t.timestamps
    end
  end
end
