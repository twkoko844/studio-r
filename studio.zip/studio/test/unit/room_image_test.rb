require 'test_helper'

class RoomImageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
