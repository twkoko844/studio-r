require 'test_helper'

class MaterialKindTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
