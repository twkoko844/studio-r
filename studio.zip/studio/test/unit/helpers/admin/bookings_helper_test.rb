require 'test_helper'

class Admin::BookingsHelperTest < ActionView::TestCase
end
