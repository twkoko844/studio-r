require 'test_helper'

class Admin::TopHelperTest < ActionView::TestCase
end
