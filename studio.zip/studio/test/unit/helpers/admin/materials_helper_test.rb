require 'test_helper'

class Admin::MaterialsHelperTest < ActionView::TestCase
end
