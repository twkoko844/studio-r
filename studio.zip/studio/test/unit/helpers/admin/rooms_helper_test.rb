require 'test_helper'

class Admin::RoomsHelperTest < ActionView::TestCase
end
