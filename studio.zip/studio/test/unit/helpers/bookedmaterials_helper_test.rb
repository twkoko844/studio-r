require 'test_helper'

class BookedmaterialsHelperTest < ActionView::TestCase
end
