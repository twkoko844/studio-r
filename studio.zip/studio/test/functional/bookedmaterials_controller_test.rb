require 'test_helper'

class BookedmaterialsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
