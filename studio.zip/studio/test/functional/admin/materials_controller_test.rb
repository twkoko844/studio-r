require 'test_helper'

class Admin::MaterialsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
