require 'test_helper'

class Admin::TopControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
